from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
import json
import os

TOKEN = os.environ.get("TOKEN")

ADMIN_LOGIN = "admin"
ADMIN_PASSWORD = "1234"

def load_users():
    try:
        with open("users.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}

def save_users(data):
    with open("users.json", "w") as f:
        json.dump(data, f, indent=2)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    users = load_users()
    uid = str(user.id)

    if uid not in users:
        users[uid] = {"name": user.first_name, "balance": 0}
        save_users(users)

    keyboard = [
        ["STARTS SOTISH", "STARTS OLISH"],
        ["💳 HISOBIM", "ADMIN"]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    await update.message.reply_text("Kerakli bo‘limni tanlang:", reply_markup=reply_markup)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    user = update.effective_user
    uid = str(user.id)
    users = load_users()

    if text == "ADMIN":
        context.user_data["auth"] = "login"
        await update.message.reply_text("Loginni kiriting:")

    elif context.user_data.get("auth") == "login":
        if text == ADMIN_LOGIN:
            context.user_data["auth"] = "parol"
            await update.message.reply_text("Parolni kiriting:")
        else:
            context.user_data["auth"] = None
            await update.message.reply_text("❌ Noto‘g‘ri login.")

    elif context.user_data.get("auth") == "parol":
        if text == ADMIN_PASSWORD:
            context.user_data["is_admin"] = True
            context.user_data["auth"] = None
            await update.message.reply_text("✅ Admin paneliga xush kelibsiz!
Yozing: ID va necha STARTS")
        else:
            context.user_data["auth"] = None
            await update.message.reply_text("❌ Noto‘g‘ri parol.")

    elif context.user_data.get("is_admin"):
        try:
            tid, amount = text.strip().split()
            if tid in users:
                users[tid]["balance"] += int(amount)
                save_users(users)
                await update.message.reply_text(f"✅ {amount} STARTS qo‘shildi.")
            else:
                await update.message.reply_text("❗ Foydalanuvchi topilmadi.")
        except:
            await update.message.reply_text("❗ Format: ID va miqdor")

    elif text == "STARTS OLISH":
        await update.message.reply_text("🔹 10 STARTS = 4000 so'm
🔹 50 STARTS = 18000 so'm")
    elif text == "STARTS SOTISH":
        await update.message.reply_text("🔸 10 STARTS = 5000 so'm
🔸 50 STARTS = 20000 so'm")
    elif text == "💳 HISOBIM":
        bal = users.get(uid, {}).get("balance", 0)
        await update.message.reply_text(f"💰 Hisobingizda: {bal} STARTS bor.")
    else:
        await update.message.reply_text("Iltimos, menyudan tanlang.")

if __name__ == "__main__":
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    print("✅ Bot ishlayapti...")
    app.run_polling()
